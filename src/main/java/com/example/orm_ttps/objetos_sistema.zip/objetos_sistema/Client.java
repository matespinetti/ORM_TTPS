package com.example.orm_ttps.objetos_sistema;

import java.util.List;

public class Client extends User {
    private List<Order> orders;
    private List<Suggestion> suggestions;
    
    public Client(String dni, String name, String surname, String email, String password) {
        super(dni, name, surname, email, password);

    }

    public List<Order> getOrders() {
        return orders;
    }

    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }

    public List<Suggestion> getSuggestions() {
        return suggestions;
    }

    public void setSuggestions(List<Suggestion> suggestions) {
        this.suggestions = suggestions;
    }


}
