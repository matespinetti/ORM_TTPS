package com.example.orm_ttps.objetos_sistema;

import java.awt.image.BufferedImage;

public class MenuComponent {
    private String name;
    private BufferedImage image;

    // Constructors

    public MenuComponent(String name, BufferedImage image) {
        this.name = name;
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BufferedImage getImage() {
        return image;
    }

    public void setImage(BufferedImage image) {
        this.image = image;
    }
}
