package com.example.orm_ttps.objetos_sistema;

public class Worker extends User {
    public Worker(String dni, String name, String surname, String email, String password) {
        super(dni, name, surname, email, password);
    }
}