package com.example.orm_ttps.objetos_sistema;

import java.awt.image.BufferedImage;

public class Food extends Product {

    private BufferedImage image;

    public Food(String name, double price, int stock, BufferedImage image) {
        super(name, price, stock);
        this.image = image;
    }

    // Getters and Setters


    public BufferedImage getImage() {
        return image;
    }

    public void setImage(BufferedImage image) {
        this.image = image;
    }
}
