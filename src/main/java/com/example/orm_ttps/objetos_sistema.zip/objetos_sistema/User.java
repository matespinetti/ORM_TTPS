package com.example.orm_ttps.objetos_sistema;

import java.awt.image.BufferedImage;
import java.time.LocalDateTime;
import java.util.List;

// Base User class
public class User {
    private String dni;
    private String name;
    private String surname;
    private String email;
    private String password;
    private BufferedImage photo;

    // Constructors

    public User(String dni, String name, String surname, String email, String password) {
        this.dni = dni;
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.password = password;
    }

    // Getters and Setters
    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSurname() { return surname; }
    public void setSurname(String surname) { this.surname = surname; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public BufferedImage getPhoto() { return photo; }
    public void setPhoto(BufferedImage photo) { this.photo = photo; }
}