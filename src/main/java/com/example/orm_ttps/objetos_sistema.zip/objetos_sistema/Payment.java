package com.example.orm_ttps.objetos_sistema;

import java.time.LocalDateTime;
import java.util.List;

public class Payment {
    private Order order;
    private LocalDateTime paymentDate;

    public Payment(Order order, LocalDateTime paymentDate) {
        this.order = order;
        this.paymentDate = paymentDate;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public LocalDateTime getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDateTime paymentDate) {
        this.paymentDate = paymentDate;
    }
}
