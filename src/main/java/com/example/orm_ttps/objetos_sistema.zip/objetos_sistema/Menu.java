package com.example.orm_ttps.objetos_sistema;

import java.util.Date;

public class Menu extends Product {
    private MenuComponent starter;
    private MenuComponent mainCourse;
    private MenuComponent dessert;
    private MenuComponent drink;
    private boolean isVegetarian;
    private Date date;

    // Constructors


    public Menu(String name, double price, int stock, MenuComponent starter, MenuComponent mainCourse, MenuComponent dessert, MenuComponent drink, boolean isVegetarian, Date date) {
        super(name, price, stock);
        this.starter = starter;
        this.mainCourse = mainCourse;
        this.dessert = dessert;
        this.drink = drink;
        this.isVegetarian = isVegetarian;
        this.date = date;
    }

    // Getters and Setters
    public MenuComponent getStarter() { return starter; }
    public void setStarter(MenuComponent starter) { this.starter = starter; }

    public MenuComponent getMainCourse() { return mainCourse; }
    public void setMainCourse(MenuComponent mainCourse) { this.mainCourse = mainCourse; }

    public MenuComponent getDessert() { return dessert; }
    public void setDessert(MenuComponent dessert) { this.dessert = dessert; }

    public MenuComponent getDrink() { return drink; }
    public void setDrink(MenuComponent drink) { this.drink = drink; }

    public boolean isVegetarian() { return isVegetarian; }
    public void setVegetarian(boolean isVegetarian) { this.isVegetarian = isVegetarian; }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}