package com.example.orm_ttps.objetos_sistema;

import jakarta.ejb.Local;

import java.time.LocalDateTime;

public class Suggestion {
    private Client client;
    private String type;
    private String suggestion;
    private LocalDateTime datetime;

    public Suggestion(Client client, String type, String suggestion, LocalDateTime datetime) {
//        this.client = client;
        this.type = type;
        this.suggestion = suggestion;
        this.datetime = datetime;
    }


    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSuggestion() {
        return suggestion;
    }

    public void setSuggestion(String suggestion) {
        this.suggestion = suggestion;
    }

    public LocalDateTime getDatetime() {
        return datetime;
    }

    public void setDatetime(LocalDateTime datetime) {
        this.datetime = datetime;
    }
}
