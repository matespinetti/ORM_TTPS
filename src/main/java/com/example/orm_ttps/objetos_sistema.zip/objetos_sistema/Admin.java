package com.example.orm_ttps.objetos_sistema;

public class Admin extends User {
    public Admin(String dni, String name, String surname, String email, String password) {
        super(dni, name, surname, email, password);
    }
}