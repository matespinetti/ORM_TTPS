package com.example.orm_ttps.objetos_sistema;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public class Order {
    private List<Product> productos;
    private Client client;
    private LocalDateTime issueDate;
    private LocalDateTime pickDate;
    private Payment payment;


    public Order(List<Product> productos, Client client, LocalDateTime issueDate, LocalDateTime pickDate) {
        this.productos = productos;
//        this.client = client;
        this.issueDate = issueDate;
        this.pickDate = pickDate;
        this.payment = null;
    }

    public List<Product> getProductos() {
        return productos;
    }

    public void setProductos(List<Product> productos) {
        this.productos = productos;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public LocalDateTime getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDateTime issueDate) {
        this.issueDate = issueDate;
    }

    public LocalDateTime getPickDate() {
        return pickDate;
    }

    public void setPickDate(LocalDateTime pickDate) {
        this.pickDate = pickDate;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }
}





